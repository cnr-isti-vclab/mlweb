#include "qcontroller.h"

QController::QController()
{
}
