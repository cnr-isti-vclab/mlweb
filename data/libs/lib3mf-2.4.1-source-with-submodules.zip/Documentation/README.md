# Documentation for lib3mf

How to build this documentation locally:

1. `pip install sphinx`

2. `pip install sphinx-tabs`

3. `cd Source`

4. `make.bat html` (or something analogous for Unix systems)


How this documentation is built on readthedocs.org:

via the `.readthedocs.yml` - file in the root folder