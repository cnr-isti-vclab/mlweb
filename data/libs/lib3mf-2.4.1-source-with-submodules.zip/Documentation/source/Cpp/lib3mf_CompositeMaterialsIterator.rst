
CCompositeMaterialsIterator
====================================================================================================


.. cpp:class:: Lib3MF::CCompositeMaterialsIterator : public CResourceIterator 

	




	.. cpp:function:: PCompositeMaterials GetCurrentCompositeMaterials()

		Returns the CompositeMaterials the iterator points at.

		:returns: returns the CompositeMaterials instance.


.. cpp:type:: std::shared_ptr<CCompositeMaterialsIterator> Lib3MF::PCompositeMaterialsIterator

	Shared pointer to CCompositeMaterialsIterator to easily allow reference counting.

