
CSliceStackIterator
====================================================================================================


.. cpp:class:: Lib3MF::CSliceStackIterator : public CResourceIterator 

	




	.. cpp:function:: PSliceStack GetCurrentSliceStack()

		Returns the SliceStack the iterator points at.

		:returns: returns the SliceStack instance.


.. cpp:type:: std::shared_ptr<CSliceStackIterator> Lib3MF::PSliceStackIterator

	Shared pointer to CSliceStackIterator to easily allow reference counting.

