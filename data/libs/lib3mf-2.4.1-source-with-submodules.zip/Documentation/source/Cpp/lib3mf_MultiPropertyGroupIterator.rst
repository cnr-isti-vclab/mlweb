
CMultiPropertyGroupIterator
====================================================================================================


.. cpp:class:: Lib3MF::CMultiPropertyGroupIterator : public CResourceIterator 

	




	.. cpp:function:: PMultiPropertyGroup GetCurrentMultiPropertyGroup()

		Returns the MultiPropertyGroup the iterator points at.

		:returns: returns the MultiPropertyGroup instance.


.. cpp:type:: std::shared_ptr<CMultiPropertyGroupIterator> Lib3MF::PMultiPropertyGroupIterator

	Shared pointer to CMultiPropertyGroupIterator to easily allow reference counting.

