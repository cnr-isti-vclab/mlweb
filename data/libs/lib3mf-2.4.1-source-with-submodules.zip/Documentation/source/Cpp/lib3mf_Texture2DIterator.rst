
CTexture2DIterator
====================================================================================================


.. cpp:class:: Lib3MF::CTexture2DIterator : public CResourceIterator 

	




	.. cpp:function:: PTexture2D GetCurrentTexture2D()

		Returns the Texture2D the iterator points at.

		:returns: returns the Texture2D instance.


.. cpp:type:: std::shared_ptr<CTexture2DIterator> Lib3MF::PTexture2DIterator

	Shared pointer to CTexture2DIterator to easily allow reference counting.

