
CTexture2DGroupIterator
====================================================================================================


.. cpp:class:: Lib3MF::CTexture2DGroupIterator : public CResourceIterator 

	




	.. cpp:function:: PTexture2DGroup GetCurrentTexture2DGroup()

		Returns the Texture2DGroup the iterator points at.

		:returns: returns the Texture2DGroup instance.


.. cpp:type:: std::shared_ptr<CTexture2DGroupIterator> Lib3MF::PTexture2DGroupIterator

	Shared pointer to CTexture2DGroupIterator to easily allow reference counting.

