
CColorGroupIterator
====================================================================================================


.. cpp:class:: Lib3MF::CColorGroupIterator : public CResourceIterator 

	




	.. cpp:function:: PColorGroup GetCurrentColorGroup()

		Returns the ColorGroup the iterator points at.

		:returns: returns the ColorGroup instance.


.. cpp:type:: std::shared_ptr<CColorGroupIterator> Lib3MF::PColorGroupIterator

	Shared pointer to CColorGroupIterator to easily allow reference counting.

