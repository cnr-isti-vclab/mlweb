
CObjectIterator
====================================================================================================


.. cpp:class:: Lib3MF::CObjectIterator : public CResourceIterator 

	




	.. cpp:function:: PObject GetCurrentObject()

		Returns the Object the iterator points at.

		:returns: returns the Object instance.


.. cpp:type:: std::shared_ptr<CObjectIterator> Lib3MF::PObjectIterator

	Shared pointer to CObjectIterator to easily allow reference counting.

