
CMeshObjectIterator
====================================================================================================


.. cpp:class:: Lib3MF::CMeshObjectIterator : public CResourceIterator 

	




	.. cpp:function:: PMeshObject GetCurrentMeshObject()

		Returns the MeshObject the iterator points at.

		:returns: returns the MeshObject instance.


.. cpp:type:: std::shared_ptr<CMeshObjectIterator> Lib3MF::PMeshObjectIterator

	Shared pointer to CMeshObjectIterator to easily allow reference counting.

