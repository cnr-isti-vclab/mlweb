
CBase
====================================================================================================


.. cpp:class:: Lib3MF::CBase 

	




.. cpp:type:: std::shared_ptr<CBase> Lib3MF::PBase

	Shared pointer to CBase to easily allow reference counting.

