.. Documentation for the C-binding of the 3MF library

*********************
C-language bindings
*********************

This space describes the usage of lib3mf in a C host application.

TODO

