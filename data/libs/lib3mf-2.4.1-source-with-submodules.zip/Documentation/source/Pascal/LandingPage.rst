.. Documentation for the Pascal-binding of the 3MF library

*************************
Pascal-language bindings
*************************

TODO
