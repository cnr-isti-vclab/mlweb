.. Documentation for the Python-binding of the 3MF library

*************************
Python-language bindings
*************************

TODO
