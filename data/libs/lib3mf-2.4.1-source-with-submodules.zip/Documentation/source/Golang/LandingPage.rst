.. Documentation for the Golang-binding of the 3MF library

*************************
Golang-language bindings
*************************

TODO
