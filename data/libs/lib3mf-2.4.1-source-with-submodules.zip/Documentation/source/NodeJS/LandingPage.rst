.. Documentation for the NodeJS-binding of the 3MF library

*************************
NodeJS-language bindings
*************************

TODO
