#!/usr/bin/env bash

mkdir ../build_qmake
cd ../build_qmake

qmake ../u3d/
make
