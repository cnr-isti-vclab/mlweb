#ifndef CORTO_H
#define CORTO_H

#include "encoder.h"
#include "decoder.h"

#endif // CORTO_H
